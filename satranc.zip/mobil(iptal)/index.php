<?php

header("Location:/web/app/controller/oyun.php?l=1");
//   /web/app/controller/oyun.php?l=1  ==> l = 1-5 level 

?>
