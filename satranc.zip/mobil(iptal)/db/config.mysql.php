<?php
define('SERVER',"localhost");
define('USER',"satranc2017");
define('PASSWORD',"u7amydu3e");
define('DATABASE',"zadmin_satranc2017");

?>
