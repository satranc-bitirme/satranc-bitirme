<?php

define('SERVER',"localhost");
define('USER',"root");
define('PASSWORD',"123456");
define('DATABASE',"zadmin_satranc");
?>
