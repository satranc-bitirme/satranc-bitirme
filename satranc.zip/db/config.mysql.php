<?php

define('SERVER',"localhost");
define('USER',"benilker_st");
define('PASSWORD',"&3YC1z7QupXO");
define('DATABASE',"benilker_st");
?>
