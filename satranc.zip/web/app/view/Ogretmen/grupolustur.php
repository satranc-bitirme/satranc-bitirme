<div class="row">
    <div class="col-md-6 col-md-offset-3">

        <form class="form-inline" action="/web/app/controller/gruplar.php?islem=grupolustur" method="post" name="grupolustur">
            <div class="form-group">
                <label for="exampleInputName2">Grup Adı:</label>
                <input type="text" class="form-control" name="grupAdi">
            </div>
            <div class="form-group">

                <input type="submit" class="btn btn-primary" value="Oluştur" name="grupolustur">
            </div>


        </form>
		<div> </div>
    </div>
</div>
