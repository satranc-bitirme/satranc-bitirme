

<div class="row">

    <div class="col-md-6">

        <form class="form-horizontal"  action="/web/app/controller/uyeol.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="text" class="form-control" name="adi"  placeholder="Adınız">
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="text" class="form-control" name="soyadi"  placeholder="Soyadınız">
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="email" class="form-control" name="eposta"  placeholder="e-Posta Adresiniz">
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="text" class="form-control" name="kullaniciadi"  placeholder="Kullanıcı Adınız">
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="date" class="form-control" name="dogumtarih"  placeholder="Doğum Tarihiniz">
					(Örneğin:06/12/1990)
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="password" class="form-control" name="sifre"  placeholder="Parola">
                </div>
            </div>

            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="password" class="form-control" name="tekrarsifre"  placeholder="Parola Onay">
                </div>
            </div>
			
            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <input type="file" class="btn btn-primary btn-block"  name="resim"  accept="image/*"  />
                </div>
            </div>
			
            <div class="form-group">
                <div class=" col-sm-offset-3 col-sm-6">
                    <button type="submit" class="btn btn-success btn-lg btn-block">Kaydet</button>
                </div>
            </div>





        </form>



    </div>
    <div class="col-md-6">
        <div class="media">


            <iframe width="420" height="250" src="https://www.youtube.com/embed/lFY92Fh7qy8" frameborder="0" allowfullscreen></iframe>

        </div>


    </div>


</div>