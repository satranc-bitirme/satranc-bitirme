Haber Eklemek için <a href="haberler.php?islem=haberekle">Tıklayınız</a><br>
Duyuru Eklemek için <a href="haberler.php?islem=duyuruekle">Tıklayınız</a><br>
