<div class="alert alert-info" role="alert">
<?php

for($i=0;$i<count($args);$i++) {


    ?>


<?php
echo $args[$i]."<br>";

}

    ?>
</div>
