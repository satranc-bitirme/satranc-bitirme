﻿<?php

header("Location:/web/app/controller/giris.php");

?>
